# ts-exam

### Install
```bash
npm i
```

### Build
```bash
npm run build
```

### Run
```bash
npm run start
```  //
